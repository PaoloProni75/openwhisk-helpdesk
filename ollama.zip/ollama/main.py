"""
OpenWhisk action entry point for Ollama service
"""
import json
import asyncio
from .models import OllamaRequest
from .client import OllamaClient
from .exceptions import OllamaException


def main(args):
    """
    OpenWhisk action entry point for Ollama LLM service
    Expected input: {
        "question": "user question",
        "context": "optional context",
        "model": "llama2",
        "temperature": 0.1,
        "max_tokens": 500
    }
    """
    try:
        # Parse request
        question = args.get('question')
        if not question:
            return {
                'error': 'Missing required parameter: question'
            }
        
        context = args.get('context')
        
        # Get configuration from args or use defaults
        model = args.get('model', 'llama2')
        temperature = args.get('temperature', 0.1)
        max_tokens = args.get('max_tokens', 500)
        base_url = args.get('base_url', 'http://localhost:11434')
        timeout = args.get('timeout', 30)
        
        # Create request
        request = OllamaRequest(question=question, context=context)
        
        # Create client
        client = OllamaClient(
            base_url=base_url,
            model=model,
            temperature=temperature,
            max_tokens=max_tokens,
            timeout=timeout
        )
        
        # Process request async
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        try:
            response = loop.run_until_complete(client.generate_response(request))
        finally:
            loop.close()
        
        return response.to_dict()
        
    except ValueError as e:
        return {
            'error': f'Invalid request: {str(e)}',
            'answer': 'Sorry, there was an error with your request.'
        }
    except OllamaException as e:
        return {
            'error': f'Ollama service error: {str(e)}',
            'answer': 'Sorry, I am currently unable to process your request. Please try again later.'
        }
    except Exception as e:
        return {
            'error': f'Internal server error: {str(e)}',
            'answer': 'Sorry, I encountered an error processing your request.'
        }


# Health check action
def health(args):
    """
    Health check action for Ollama service
    """
    try:
        base_url = args.get('base_url', 'http://localhost:11434')
        client = OllamaClient(base_url=base_url)
        
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        try:
            is_healthy = loop.run_until_complete(client.health_check())
        finally:
            loop.close()
        
        return {
            'healthy': is_healthy,
            'service': 'ollama',
            'base_url': base_url
        }
    except Exception as e:
        return {
            'healthy': False,
            'service': 'ollama',
            'error': str(e)
        }


# For local testing
if __name__ == '__main__':
    # Test main function
    test_args = {
        'question': 'How can I reset my password?',
        'context': 'The user is asking about password reset procedures.',
        'model': 'llama2'
    }
    
    print("Testing main function:")
    result = main(test_args)
    print(json.dumps(result, indent=2))
    
    # Test health check
    print("\nTesting health check:")
    health_result = health({})
    print(json.dumps(health_result, indent=2))