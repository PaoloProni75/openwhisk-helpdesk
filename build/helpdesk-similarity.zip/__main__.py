import sys
import os
sys.path.append(os.path.dirname(__file__))
from main import main
